##### log transformation #####

x_var <- rnorm(50)
intercept <- runif(1, -1, 1)
slope <- runif(1, 0.5, 2)
y_var <- exp(intercept + slope * x_var + rnorm(length(x_var)))

plot(x_var, y_var)
plot(x_var, log(y_var))

m1 <- lm(y_var ~ x_var)
plot(x_var, y_var)
abline(m1)

par(mfrow = c(2,2))
plot(m1)
hist(resid(m1))
plot(y_var, predict(m1))
abline(0, 1)
par(mfrow = c(1,1))

m2 <- glm(y_var ~ x_var, family = 'poisson')
# silencing the warning requires y-values to be integers
plot(x_var, log(y_var))
abline(m2)

par(mfrow = c(2,2))
plot(m2)
hist(resid(m2))
plot(y_var, predict(m2))
abline(0, 1)

#####

plot(x_var, y_var)
lines(x_var, predict(m1), col = 'red')
points(x_var, exp(predict(m2)), col = 'green')

##### logit transformation #####

x_var <- rnorm(50)
intercept <- runif(1, -0.3, 0.3)
slope <- runif(1, 3, 5)
y_var <- 1 / (1 + exp(-(intercept + slope * x_var + rnorm(length(x_var), 0, 1))))
# if you get few values < 0.5, maybe try with a different intercept

plot(x_var, y_var)
plot(x_var, log(y_var / (1 - y_var)))

m1 <- lm(y_var ~ x_var)
plot(x_var, y_var)
abline(m1)

par(mfrow = c(2,2))
plot(m1)
hist(resid(m1))
plot(y_var, predict(m1))
abline(0, 1)
par(mfrow = c(1,1))

m2 <- glm(y_var ~ x_var, family = 'binomial')
plot(x_var, log(y_var / (1 - y_var)))
abline(m2)

par(mfrow = c(2,2))
plot(m2)
hist(resid(m2))
plot(y_var, 1/(1+exp(-predict(m2))))
abline(0, 1)

#####

plot(x_var, y_var)
points(x_var, predict(m1), col = 'red')
points(x_var, 1 / (1 + exp(-predict(m2))), col = 'green')

# predict(m1, newdata = list('x_var' = seq(-8, 8)))
# 1 / (1 + exp(-predict(m2, newdata = list('x_var' = seq(-8, 8)))))

##### logit - binary #####

y_var_md <- median(y_var)
y_var[y_var <= y_var_md] <- 0
y_var[y_var > y_var_md] <- 1

plot(x_var, y_var)

m1 <- lm(y_var ~ x_var)
plot(x_var, y_var)
abline(m1)

m2 <- glm(y_var ~ x_var, family = 'binomial')

plot(x_var, y_var)
lines(sort(x_var), 1/(1+exp(-predict(m2, newdata = list('x_var' = sort(x_var))))))

y_var[y_var == 1] <- 0.99
y_var[y_var == 0] <- 0.01
plot(x_var, log(y_var / (1-y_var)))
lines(sort(x_var), predict(m2, newdata = list('x_var' = sort(x_var))))

summary(m2)
plot(m2)

##### Random roots or logarithms #####

### logarithm ###

intercept <- runif(1, -1, 1)
slope <- runif(1, 0.5, 2)
y_var <- 3**(slope + slope * x_var + rnorm(length(x_var), 0, 0.5))

plot(x_var, y_var)
plot(x_var, log(y_var, base = 3))

m1 <- lm(y_var ~ x_var)
plot(x_var, y_var)
abline(m1)

par(mfrow = c(2,2))
plot(m1)
hist(resid(m1))
plot(y_var, predict(m1))
abline(0, 1)
par(mfrow = c(1,1))

m2 <- glm(log(y_var, base = 3) ~ x_var)
plot(x_var, log(y_var, base = 3))
abline(m2)

par(mfrow = c(2,2))
plot(m2)
hist(resid(m2))
plot(y_var, 3**predict(m2))
abline(0, 1)
par(mfrow = c(1,1))

### root ###

intercept <- runif(1, -1, 1)
slope <- runif(1, 0.5, 2)
y_var <- intercept + slope * x_var + rnorm(length(x_var))
y_var <- y_var - min(y_var)
y_var <- y_var**3

plot(x_var, y_var)
plot(x_var, y_var**(1/3))

m1 <- lm(y_var ~ x_var)
plot(x_var, y_var)
abline(m1)

par(mfrow = c(2,2))
plot(m1)
hist(resid(m1))
plot(y_var, predict(m1))
abline(0, 1)
par(mfrow = c(1,1))

m2 <- glm(y_var**(1/3) ~ x_var)
plot(x_var, y_var**(1/3))
abline(m2)

par(mfrow = c(2,2))
plot(m2)
hist(resid(m2))
plot(y_var, predict(m2)**3)
abline(0, 1)



### show gamma and negativ-binomial also (just for means of find 
# the "best" distribution, not necessarily a "biologically-explainable" one)
### more complicated models with both types of transformation
### one example with nls? (SR) as a special task?
### one example with TMB? as a special task?








